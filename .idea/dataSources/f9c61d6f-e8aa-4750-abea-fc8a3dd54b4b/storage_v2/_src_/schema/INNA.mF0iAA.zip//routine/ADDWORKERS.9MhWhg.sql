create procedure "ADDWORKERS"
(nom IN NUMBER,name IN VARCHAR, par IN VARCHAR)
is
begin
  insert into workers(empno,ename) values(nom,name);
  insert into HIERARCHY(parent_id, child_id, depth) select nom,nom,0 from dual
  union all select parent_id,nom,depth+1 from HIERARCHY where child_id=(select empno from WORKERS where ename =par);
  /*insert into HIERARCHY(parent_id, child_id, depth) VALUES */
end;
/

