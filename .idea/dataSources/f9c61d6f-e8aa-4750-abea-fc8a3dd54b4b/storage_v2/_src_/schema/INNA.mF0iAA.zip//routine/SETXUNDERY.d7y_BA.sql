create procedure "SETXUNDERY"
(nowparentx in VARCHAR,underrx in VARCHAR, x IN VARCHAR)
is
begin
  update HIERARCHY set parent_id=(select empno from WORKERS where ename=underrx)
  where parent_id=(select empno from WORKERS where ename = nowparentx)
    and child_id=(select empno from WORKERS where ename=x);
    update HIERARCHY set depth = (select c.depth+p.depth from HIERARCHY c join HIERARCHY p on(c.parent_id=p.parent_id) where c.depth!=0 and p.depth!=0 group by c.parent_id)
    where parent_id=(select empno from workers where ename=x);
  /*update HIERARCHY set DEPTH=(select th.depth+par.depth from HIERARCHY th, HIERARCHY par)
    where parent_id=(select empno from WORKERS where ename=underrx)
          and child_id=(select empno from WORKERS where ename=x);*/
end;
/

