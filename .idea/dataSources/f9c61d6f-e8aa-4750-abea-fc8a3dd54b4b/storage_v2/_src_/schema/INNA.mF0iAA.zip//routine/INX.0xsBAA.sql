create procedure "INX"
(x IN VARCHAR, res out StringList)
as
begin
  select * into res FROM  WORKERS w join HIERARCHY h on(w.empno=h.child_id)
  where h.parent_id=(select empno from WORKERS where ename = x) and h.parent_id != 0;
end;
/

