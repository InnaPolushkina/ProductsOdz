create trigger BI_TESTT
  before insert
  on TESTT
  for each row
begin
  if :NEW."T_ID" is null then
    select "TESTT_SEQ".nextval into :NEW."T_ID" from dual;
  end if;
end;
/

