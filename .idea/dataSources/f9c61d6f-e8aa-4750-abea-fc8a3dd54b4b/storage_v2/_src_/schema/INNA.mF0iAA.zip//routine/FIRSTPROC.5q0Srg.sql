create procedure "FIRSTPROC"
(nom IN NUMBER,name IN VARCHAR)
is
begin
  insert into workers(empno,ename) values(nom,name);
end;
/

