create function depthx(x varchar) return number
is l_list number;
begin
  select max(h.DEPTH)+1 into l_list from WORKERS w join HIERARCHY h on (w.empno=h.child_id)
  where w.ename=x group by w.ename;
  return l_list;
end;
/

