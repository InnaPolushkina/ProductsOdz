create function parx(x varchar) return varchar
is l_list varchar(20);
begin
  select w.ename into l_list from WORKERS w join HIERARCHY h on(w.empno=h.parent_id)
  where h.child_id=(select empno from WORKERS where ename =x) and h.depth = (select max(depth) from WORKERS a join HIERARCHY b on(a.empno=b.child_id)
   where a.ename=x group by a.ename);
  return l_list;
end;
/

