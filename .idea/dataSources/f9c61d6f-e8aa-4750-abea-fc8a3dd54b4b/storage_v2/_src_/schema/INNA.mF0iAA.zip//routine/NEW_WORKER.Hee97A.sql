create procedure new_Worker(id int, name varchar(20), parent int, path int) is
new_empno int;
  new_ename varchar(20);
  new_parent int;
  new_path int;
  begin
    new_empno:=id;
    new_ename:=name;
    new_parent:=parent;
    new_path:=parent;
    insert into WORKERS(empno, ename) VALUES  (new_empno,new_ename);
    insert into HIERARCHY(parent_id, child_id, depth) select new_empno,new_empno,0 from dual union all select parent_id,new_empno,depth+1 from HIERARCHY where child_id=(select empno from WORKERS where ename ='KING');
   commit ;
  end;
/

