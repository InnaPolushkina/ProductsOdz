create procedure "REMOVEWORKERS"
(name IN VARCHAR)
is
begin
  delete from HIERARCHY where parent_id=(select empno from WORKERS where ename=name) or child_id=(select empno from WORKERS where ename=name);
  delete from WORKERS where ename = name;
end;
/

