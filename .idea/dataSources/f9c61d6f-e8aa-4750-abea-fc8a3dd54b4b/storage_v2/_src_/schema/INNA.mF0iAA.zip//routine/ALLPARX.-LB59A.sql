create function allparx(x varchar) return StringList
is l_list StringList;
begin
  select cast(w.ename as varchar(30))  BULK COLLECT into l_list from WORKERS w join HIERARCHY h
  on(w.empno=h.parent_id) where h.child_id=(select empno from WORKERS where ename =x) and h.depth!=0 order by h.depth;
  return l_list;
end;
/

