create procedure depthxpro(x varchar)
is
begin
  select max(h.depth)  from w join HIERARCHY h on (w.empno=h.child_id)
  where w.ename=x group by w.ename;

end;
/

